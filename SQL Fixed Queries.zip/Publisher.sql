CREATE TABLE Publisher (

Publisher_id int NOT NULL PRIMARY KEY,
Publisher_name varchar(255) NOT NULL

)

