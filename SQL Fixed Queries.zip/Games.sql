CREATE TABLE Games (

App_id int NOT NULL Primary KEY,
App_name varchar(255),
released varchar(255),
genre varchar(255),
sales int NOT NULL,
developer int NOT NULL,
publisher int NOT NULL,
price float NOT NULL,
score float NOT NULL

)
