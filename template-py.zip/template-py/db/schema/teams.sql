-- Table: teams

-- DROP TABLE teams;

CREATE TABLE teams
(
  "TEAM_ID" bigint,
  "TEAM_NAME" text
)
WITH (
  OIDS=FALSE
);