CREATE TABLE Developer (

D_id int NOT NULL PRIMARY KEY,
D_name varchar(255) NOT NULL,

FOREIGN KEY (D_id) REFERENCES games(developer)
)

