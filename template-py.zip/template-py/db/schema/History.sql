CREATE TABLE History (
    History_id integer NOT NULL DEFAULT nextval('history_history_id_seq'::regclass),
    App_id int NOT NULL,
    Score double NOT NULL,
    Price float NOT NULL,
    YearMonth varchar(255) NOT NULL,
   
)

