import requests
import json
from urllib2 import urlopen

response = requests.get("http://api.steampowered.com/ISteamApps/GetAppList/v0001/")
url = "http://api.steampowered.com/ISteamApps/GetAppList/v0001/"
#test = json.load(response)
#print test
data = response.json()
get = urlopen(url)
json_object = json.load(get)
#int(type(data))

for Apps in json_object['applist']['apps']['app']:
    if (Apps['appid'] < 500):
        getprice = requests.get('http://store.steampowered.com/api/appdetails/?appids=%d&filters=price_overview&cc=us' % Apps['appid'])
        getdev = requests.get(
            'http://store.steampowered.com/api/appdetails/?appids=%d&filters=developers&cc=us' % Apps['appid'])
        getpub = requests.get(
            'http://store.steampowered.com/api/appdetails/?appids=%d&filters=publishers&cc=us' % Apps['appid'])
        getdate = requests.get(
            'http://store.steampowered.com/api/appdetails/?appids=%d&filters=release_date&cc=us' % Apps['appid'])
        getscore = requests.get(
            'http://store.steampowered.com/api/appdetails/?appids=%d&filters=metacritic&cc=us' % Apps['appid'])

        if getprice.status_code == 200:
            rjson = json.loads(getprice.text)
            djson = json.loads(getdev.text)
            pjson = json.loads(getpub.text)
            tjson = json.loads(getdate.text)
            mjson = json.loads(getscore.text)
            # use the appid to fetch the value and convert to decimal
            # appid is numeric, cast to string to lookup the price
            try:
                price = rjson[str(Apps['appid'])]['data']['price_overview']['initial'] * .01
            except:
                price = 0
            try:
                developer = djson[str(Apps['appid'])]['data']['developers'][0]
            except:
                developer = 'N/A'
            try:
                publisher = pjson[str(Apps['appid'])]['data']['publishers'][0]
            except:
                publisher = 'N/A'
            try:
                date = tjson[str(Apps['appid'])]['data']['release_date']['date']
            except:
                date = 'N/A'
            try:
                score = mjson[str(Apps['appid'])]['data']['metacritic']['score']
                #print score
            except:
                score = 0

            Apps[Apps['appid']] = {'name': Apps['name'], 'price': price, 'developer': developer, 'publisher': publisher, 'date': date, 'score': score}
            print Apps


print(response.status_code)