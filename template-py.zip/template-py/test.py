import requests
import json

response = requests.get("http://api.steampowered.com/ISteamUserStats/GetSchemaForGame/v2/?key=71129C29789B990AD2EFE630F3C4678C&appid=218620&format=json")

#test = json.load(response)
#print test
data = response.json()
#int(type(data))
print(data)

print(response.status_code)