import requests
import json
from urllib2 import urlopen

response = requests.get("http://api.steampowered.com/ISteamApps/GetAppList/v0001/")
url = "http://api.steampowered.com/ISteamApps/GetAppList/v0001/"
#test = json.load(response)
#print test
data = response.json()
get = urlopen(url)
json_object = json.load(get)
#int(type(data))

for Apps in json_object['applist']['apps']['app']:
    if (Apps['appid'] < 500):
        getprice = requests.get('http://store.steampowered.com/api/appdetails/?appids=%d&filters=price_overview&cc=us' % Apps['appid'])
        if getprice.status_code == 200:
            rjson = json.loads(getprice.text)
            # use the appid to fetch the value and convert to decimal
            # appid is numeric, cast to string to lookup the price
            try:
                price = rjson[str(Apps['appid'])]['data']['price_overview']['initial'] * .01
            except:
                price = 0
            Apps[Apps['name']] = {'price': price, 'appid': Apps['appid']}
            print Apps


print(response.status_code)